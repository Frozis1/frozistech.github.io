import About from "./components/About";
import Contact, { Footer } from "./components/Contact";
import Hero from "./components/Hero";
import Nav from "./components/Nav";
import Scales from "./components/Scales";
import Services from "./components/Services";
import Work from "./components/Work";
import { useScrollReveal, useScrollY } from "./lib/hooks";

const TICKER = [
  "Technology & IT Support",
  "STEM Education & Robotics",
  "Web & Mobile Applications",
  "Digital Marketing & Paid Ads",
  "Graphic Design & Branding",
  "AI Automation & Tools",
  "Networking & Cybersecurity",
];

function Ticker() {
  const row = [...TICKER, ...TICKER];
  return (
    <div className="relative overflow-hidden border-y border-white/10 bg-[linear-gradient(90deg,#0a1c33,#12395f_50%,#0a1c33)] py-3.5">
      <div className="marquee-track flex w-max items-center gap-8">
        {row.map((t, i) => (
          <span key={`${t}-${i}`} className="flex items-center gap-8 whitespace-nowrap">
            <span className="font-display text-[0.78rem] font-semibold uppercase tracking-[.24em] text-white/70">{t}</span>
            <span className="h-1.5 w-1.5 rotate-45 bg-brand-400" />
          </span>
        ))}
      </div>
    </div>
  );
}

function ToTop() {
  const y = useScrollY();
  return (
    <button
      type="button"
      aria-label="Back to top"
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      className={`fixed bottom-6 right-5 z-40 grid h-12 w-12 place-items-center rounded-full border border-white/15 bg-navy-900/90 text-brand-300 backdrop-blur-md transition-all duration-500 hover:border-brand-400 hover:text-white hover:shadow-glow ${
        y > 700 ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-4 opacity-0"
      }`}
    >
      <svg viewBox="0 0 24 24" fill="none" className="w-5" aria-hidden="true">
        <path
          d="M12 19V5m0 0-6 6m6-6 6 6"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </button>
  );
}

export default function App() {
  useScrollReveal();

  return (
    <div className="min-h-screen bg-navy-900">
      <Nav />
      <main>
        <Hero />
        <Ticker />
        <About />
        <Services />
        <Scales />
        <Work />
        <Contact />
      </main>
      <Footer />
      <ToTop />
    </div>
  );
}
