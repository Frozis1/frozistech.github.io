import { ArrowIcon } from "./Icons";
import { SectionHeading } from "./ui";

const PROJECTS = [
  {
    tag: "Web application",
    title: "EduTrack School Portal",
    copy: "Admissions, grading, fees and parent messaging for a 900-student school in Accra — replacing four spreadsheets and a filing cabinet.",
    stack: ["React", "Flask", "MySQL", "Tailwind"],
    image: "/images/project-dashboard.jpg",
    metric: "70% less admin time",
    featured: true,
  },
  {
    tag: "STEM program",
    title: "Robotics Club in a Box",
    copy: "A 12-week curriculum with Arduino kits, lesson plans and teacher training, now running in three junior high schools.",
    stack: ["Arduino", "Scratch", "Python", "Training"],
    image: "/images/project-stem.jpg",
    metric: "240 students reached",
  },
  {
    tag: "Networking",
    title: "Clinic Network Overhaul",
    copy: "Structured cabling, segmented Wi-Fi, firewall hardening and automated off-site backups for a busy medical facility.",
    stack: ["MikroTik", "VLANs", "Firewall", "Backup"],
    image: "/images/project-network.jpg",
    metric: "99.9% uptime since launch",
  },
  {
    tag: "Brand & growth",
    title: "Kitchen Startup Launch Kit",
    copy: "Logo system, packaging, menu design and a Meta ads funnel that filled a new food brand's first three months of orders.",
    stack: ["Illustrator", "Meta Ads", "Copywriting"],
    image: "/images/hero-design.jpg",
    metric: "3.1× return on ad spend",
  },
];

export default function Work() {
  return (
    <section id="work" className="relative overflow-hidden py-20 sm:py-28">
      <div className="pointer-events-none absolute -left-32 bottom-20 h-96 w-96 rounded-full bg-brand-600/12 blur-[130px]" />

      <div className="relative mx-auto max-w-[1200px] px-5 sm:px-8">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHeading
            eyebrow="Selected work"
            script="learning turned into solutions"
            title="Projects that"
            accent="shipped"
            copy="A snapshot of recent builds across schools, clinics and small businesses in Greater Accra."
          />
          <a
            href="#contact"
            className="group inline-flex items-center gap-2 rounded-full border border-white/20 px-5 py-3 text-sm font-semibold text-white transition-colors duration-300 hover:border-brand-400 hover:text-brand-300"
          >
            Start your project
            <ArrowIcon className="w-4 transition-transform duration-300 group-hover:translate-x-1" />
          </a>
        </div>

        <ul className="mt-14 grid gap-6 lg:grid-cols-2">
          {PROJECTS.map((p, i) => (
            <li
              key={p.title}
              className={`reveal group relative overflow-hidden rounded-2xl border border-white/10 bg-navy-850/60 transition-all duration-500 hover:-translate-y-1.5 hover:border-brand-400/40 hover:shadow-glow ${
                p.featured ? "lg:col-span-2" : ""
              }`}
              data-dir={i % 2 === 0 ? "left" : "right"}
            >
              <div className={`grid ${p.featured ? "lg:grid-cols-[1.15fr_1fr]" : ""}`}>
                <div className="relative overflow-hidden">
                  <img
                    src={p.image}
                    alt={p.title}
                    loading="lazy"
                    className={`w-full object-cover brightness-[.85] transition-transform duration-[1400ms] ease-out group-hover:scale-[1.07] ${
                      p.featured ? "aspect-[16/10] lg:aspect-auto lg:h-full" : "aspect-[16/10]"
                    }`}
                  />
                  <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(160deg,rgba(11,42,74,.55),rgba(5,15,29,.8))] mix-blend-multiply" />
                  <span className="absolute left-4 top-4 rounded-full border border-white/20 bg-navy-900/70 px-3.5 py-1.5 text-[0.66rem] font-semibold uppercase tracking-[.16em] text-brand-300 backdrop-blur-sm">
                    {p.tag}
                  </span>
                  <span className="absolute bottom-4 left-4 rounded-full bg-brand-500 px-3.5 py-1.5 text-[0.7rem] font-semibold text-white shadow-glow">
                    {p.metric}
                  </span>
                </div>

                <div className="flex flex-col justify-center p-6 sm:p-8">
                  <h3 className="font-display text-xl font-extrabold text-white sm:text-2xl">{p.title}</h3>
                  <p className="mt-3 text-[0.9rem] leading-relaxed text-white/55">{p.copy}</p>
                  <ul className="mt-5 flex flex-wrap gap-2">
                    {p.stack.map((s) => (
                      <li
                        key={s}
                        className="rounded-md border border-white/10 bg-white/5 px-2.5 py-1 text-[0.68rem] font-semibold tracking-wide text-white/60 transition-colors group-hover:border-brand-400/30 group-hover:text-brand-300"
                      >
                        {s}
                      </li>
                    ))}
                  </ul>
                  <span className="mt-6 inline-flex items-center gap-2 text-[0.8rem] font-semibold text-white/70 transition-colors duration-300 group-hover:text-brand-400">
                    View case study
                    <ArrowIcon className="w-4 transition-transform duration-300 group-hover:translate-x-1.5" />
                  </span>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
