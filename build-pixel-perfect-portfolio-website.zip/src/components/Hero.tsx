import {
  AnalyticsLogo,
  CartIcon,
  CloudGearIcon,
  CodeTile,
  DesignTile,
  FlaskLogo,
  GhanaFlag,
  GoogleLogo,
  InstagramLogo,
  ItSupportTile,
  LaptopIcon,
  LogoMark,
  MailIcon,
  MarketingTile,
  MetaLogo,
  NodeLogo,
  PhoneIcon,
  PinIcon,
  PythonLogo,
  ReactLogo,
  ShieldIcon,
  StemTile,
  ToolsIcon,
  TSLogo,
  WhatsAppLogo,
  AiTile,
} from "./Icons";
import { useScrollY } from "../lib/hooks";

/* ------------------------------------------------------------------ */
/* Shared content                                                      */
/* ------------------------------------------------------------------ */

const HEADLINE = ["TECHNOLOGY & IT SUPPORT", "STEM EDUCATION", "DIGITAL SERVICES"];

const SERVICES = [
  { Icon: CodeTile, label: ["Coding &", "Programming"] },
  { Icon: ItSupportTile, label: ["IT Support &", "Computer Repairs"] },
  { Icon: StemTile, label: ["STEM Education", "& Robotics"] },
  { Icon: MarketingTile, label: ["Digital Marketing", "& Paid Ads"] },
  { Icon: DesignTile, label: ["Graphic Design", "& Creative Services"] },
  { Icon: AiTile, label: ["AI Automation", "& Tools"] },
];

const CONTACT = [
  { Icon: PinIcon, text: "Greater Accra, Ghana", href: "https://maps.google.com/?q=Accra,+Ghana" },
  { Icon: PhoneIcon, text: "+233 546 093 300", href: "tel:+233546093300" },
  { Icon: MailIcon, text: "richardadjeimenz24@gmail.com", href: "mailto:richardadjeimenz24@gmail.com" },
];

const STRIP = [
  { Icon: LaptopIcon, label: ["Web & Mobile", "Applications"] },
  { Icon: ToolsIcon, label: ["Computer Repairs", "& Upgrades"] },
  { Icon: CartIcon, label: ["Device Sales", "& Accessories"] },
  { Icon: ShieldIcon, label: ["Networking &", "Cybersecurity"] },
  { Icon: CloudGearIcon, label: ["AI Automation", "& Workflow Support"] },
];

/* ------------------------------------------------------------------ */
/* Collage                                                             */
/* ------------------------------------------------------------------ */

const PANELS = [
  {
    src: "/images/hero-code.jpg",
    alt: "Code on a developer monitor",
    clip: "polygon(0% 0%, 54% 0%, 50% 56.5%, 0% 56.5%)",
    pos: "center 42%",
  },
  {
    src: "/images/hero-repair.jpg",
    alt: "Technician repairing a laptop motherboard",
    clip: "polygon(54.5% 0%, 100% 0%, 100% 53%, 50.5% 53%)",
    pos: "center 35%",
  },
  {
    src: "/images/hero-robot.jpg",
    alt: "STEM robotics kit on a workbench",
    clip: "polygon(0% 57%, 51.5% 57%, 48.5% 100%, 0% 100%)",
    pos: "center 55%",
  },
  {
    src: "/images/hero-design.jpg",
    alt: "Graphic design workspace with app mockups",
    clip: "polygon(52% 57%, 90% 57%, 87.5% 100%, 48.5% 100%)",
    pos: "center 50%",
  },
];

function Collage({ className = "" }: { className?: string }) {
  return (
    <div className={`relative h-full w-full ${className}`}>
      {PANELS.map((p) => (
        <div key={p.src} className="absolute inset-0 overflow-hidden" style={{ clipPath: p.clip }}>
          <img
            src={p.src}
            alt={p.alt}
            className="h-full w-full scale-[1.07] object-cover brightness-[.9] saturate-[1.05] transition-transform duration-[1600ms] ease-out group-hover/collage:scale-[1.13]"
            style={{ objectPosition: p.pos }}
          />
          <div className="absolute inset-0 bg-[linear-gradient(155deg,rgba(11,42,74,.6),rgba(4,12,24,.74))] mix-blend-multiply" />
          <div className="absolute inset-0 bg-[radial-gradient(120%_90%_at_20%_10%,rgba(30,143,245,.3),transparent_62%)]" />
        </div>
      ))}

      {/* dark end panel */}
      <div
        className="absolute inset-0 bg-[linear-gradient(150deg,#0d2647_0%,rgba(7,19,34,.6)_60%,#050f1d_100%)]"
        style={{ clipPath: "polygon(90.5% 57%, 100% 53%, 100% 100%, 87.5% 100%)" }}
      />

      {/* panel separators */}
      <svg
        className="pointer-events-none absolute inset-0 h-full w-full"
        viewBox="0 0 100 100"
        preserveAspectRatio="none"
        aria-hidden="true"
      >
        <g stroke="rgba(6,16,31,.9)" strokeWidth="0.5" fill="none">
          <path d="M54.2 0 L50.8 53 L48.8 100" />
          <path d="M0 56.7 L51.6 57.1 L90 57.1" />
        </g>
        <g stroke="rgba(130,195,255,.45)" strokeWidth="0.14" fill="none">
          <path d="M54.2 0 L50.8 53 L48.8 100" />
          <path d="M0 56.7 L51.6 57.1 L90 57.1" />
          <path d="M100 52.9 L90.6 57.1 L87.6 100" />
        </g>
      </svg>

      {/* fade into the banner */}
      <div className="pointer-events-none absolute inset-y-0 left-0 w-[18%] bg-[linear-gradient(90deg,#06101f_0%,rgba(6,16,31,.7)_38%,transparent_100%)]" />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(85%_55%_at_88%_0%,rgba(30,143,245,.32),transparent_60%)]" />

      {/* tech stack logos */}
      <div className="absolute left-[26%] top-[7%] flex w-[38%] flex-wrap items-center justify-center gap-x-[8%] gap-y-[6%]">
        <ReactLogo className="w-[18%] drop-shadow-[0_4px_14px_rgba(0,0,0,.55)]" />
        <TSLogo className="w-[16%] rounded-[16%] drop-shadow-[0_4px_14px_rgba(0,0,0,.55)]" />
        <NodeLogo className="w-[38%] drop-shadow-[0_4px_14px_rgba(0,0,0,.55)]" />
        <PythonLogo className="w-[15%] drop-shadow-[0_4px_14px_rgba(0,0,0,.55)]" />
        <FlaskLogo className="w-[42%] drop-shadow-[0_4px_14px_rgba(0,0,0,.55)]" />
      </div>

      {/* social + growth logos */}
      <div className="absolute left-[59%] top-[60%] grid w-[12%] grid-cols-2 gap-[14%] drop-shadow-[0_6px_16px_rgba(0,0,0,.6)]">
        <MetaLogo className="w-full" />
        <GoogleLogo className="w-[80%]" />
        <WhatsAppLogo className="w-[80%]" />
        <InstagramLogo className="w-[80%]" />
        <AnalyticsLogo className="w-[80%]" />
      </div>

      {/* from learning to creating solutions */}
      <div className="absolute right-[2.5%] top-[58.5%] w-[24%] text-right">
        <p className="font-display text-[1.32cqw] font-bold leading-[1.16] tracking-[.01em] text-white">
          From
          <br />
          Learning
          <br />
          to
        </p>
        <p className="mt-[0.45cqw] font-script text-[2.45cqw] leading-[1.02] text-brand-400">
          Creating
          <br />
          Solutions
        </p>
        <svg viewBox="0 0 120 12" className="ml-auto mt-[0.4cqw] w-[72%]" aria-hidden="true">
          <path d="M2 8c34-6 76-7 116-3" stroke="#3aa9ff" strokeWidth="2.6" fill="none" strokeLinecap="round" />
        </svg>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Hero                                                                */
/* ------------------------------------------------------------------ */

export default function Hero() {
  const scrollY = useScrollY();

  return (
    <header id="home" className="relative isolate w-full overflow-hidden bg-navy-900">
      {/* ============================ DESKTOP BANNER ============================ */}
      <div className="relative hidden w-full lg:block" style={{ aspectRatio: "2000 / 768", containerType: "inline-size" }}>
        {/* banner canvas */}
        <div className="absolute inset-x-0 top-0 h-[31cqw] overflow-hidden bg-[radial-gradient(120%_130%_at_18%_0%,#123457_0%,#0a1c33_42%,#050f1d_100%)]">
          {/* corner geometry */}
          <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 2000 620" aria-hidden="true">
            <defs>
              <linearGradient id="cornerBlue" x1="0" y1="0" x2="1" y2="1">
                <stop stopColor="#5dbcff" />
                <stop offset="0.55" stopColor="#1e7fd8" />
                <stop offset="1" stopColor="#0e4c92" />
              </linearGradient>
              <linearGradient id="cornerNavy" x1="0" y1="0" x2="1" y2="1">
                <stop stopColor="#133a60" />
                <stop offset="1" stopColor="#0a1c33" />
              </linearGradient>
            </defs>
            <polygon points="0,0 236,0 0,236" fill="url(#cornerBlue)" />
            <polygon points="0,262 262,0 274,0 0,274" fill="#8fd0ff" opacity=".5" />
            <polygon points="0,300 300,0 470,0 0,470" fill="url(#cornerNavy)" opacity=".8" />
            <polygon points="0,620 0,404 216,620" fill="url(#cornerNavy)" />
            <polygon points="0,388 232,620 256,620 0,364" fill="#3aa9ff" opacity=".38" />
            <polygon points="2000,0 2000,118 1834,0" fill="#12395f" opacity=".4" />
            <polygon points="2000,620 2000,468 1776,620" fill="#0d2a4a" opacity=".55" />
          </svg>

          <div className="pointer-events-none absolute inset-0 grid-lines opacity-50" />
          <div className="pointer-events-none absolute left-[-8cqw] top-[6cqw] h-[34cqw] w-[34cqw] rounded-full bg-brand-500/12 blur-[7cqw]" />

          {/* logo */}
          <a
            href="#home"
            className="group absolute left-[4.2cqw] top-[5.6cqw] block w-[7.6cqw] text-white transition-transform duration-500 hover:scale-[1.05]"
            aria-label="Richard Adjei Mensah — home"
          >
            <LogoMark className="w-full drop-shadow-[0_0.3cqw_0.9cqw_rgba(0,0,0,.5)]" />
          </a>

          {/* identity block */}
          <div className="absolute left-[15.1cqw] top-[5.9cqw]">
            <h1 className="whitespace-nowrap font-display text-[2.95cqw] font-extrabold leading-[1.05] tracking-[.004em] text-white">
              RICHARD <span className="text-brand-500">ADJEI</span> MENSAH
            </h1>

            <ul className="mt-[1.28cqw] flex items-center whitespace-nowrap font-display text-[0.82cqw] font-semibold tracking-[.13em] text-white">
              {HEADLINE.map((t, i) => (
                <li key={t} className="flex items-center">
                  {i > 0 && <span className="mx-[1.1cqw] h-[0.95cqw] w-px bg-white/45" />}
                  <span className="transition-colors duration-300 hover:text-brand-300">{t}</span>
                </li>
              ))}
            </ul>

            <ul className="mt-[1.4cqw] flex items-center whitespace-nowrap text-[0.83cqw] font-medium text-white">
              {CONTACT.map(({ Icon, text, href }, i) => (
                <li key={text} className="flex items-center">
                  {i > 0 && <span className="mx-[1.1cqw] h-[1.3cqw] w-px bg-white/35" />}
                  <a
                    href={href}
                    target={href.startsWith("http") ? "_blank" : undefined}
                    rel="noreferrer"
                    className="group flex items-center gap-[0.5cqw] transition-colors duration-300 hover:text-brand-300"
                  >
                    <Icon className="w-[0.98cqw] text-brand-500 transition-transform duration-300 group-hover:-translate-y-[0.12cqw]" />
                    <span>{text}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* script tagline */}
          <div className="absolute left-[2.9cqw] top-[17.9cqw] -rotate-[3deg]">
            <p className="whitespace-nowrap font-script text-[2.15cqw] leading-[1.14] text-white drop-shadow-[0_2px_10px_rgba(0,0,0,.5)]">
              Building Skills
              <br />
              <span className="pl-[1.3cqw]">for a Smarter Future</span>
            </p>
            <svg viewBox="0 0 300 16" className="mt-[0.5cqw] w-[13.6cqw]" aria-hidden="true">
              <path d="M3 12C70 4 160 2 297 6" stroke="#3aa9ff" strokeWidth="3" fill="none" strokeLinecap="round" />
              <path
                d="M14 15C80 8 165 6 290 9.5"
                stroke="#1e8ff5"
                strokeWidth="1.6"
                fill="none"
                strokeLinecap="round"
                opacity=".6"
              />
            </svg>
          </div>

          {/* service tiles */}
          <ul className="absolute left-[21cqw] top-[22cqw] flex w-[44.6cqw] items-stretch divide-x divide-white/18">
            {SERVICES.map(({ Icon, label }) => (
              <li key={label[0]} className="flex flex-1">
                <a
                  href="#services"
                  className="group flex w-full flex-col items-center px-[0.22cqw] pt-[0.2cqw] text-center transition-colors duration-500 hover:bg-white/5"
                >
                  <Icon className="w-[2.45cqw] transition-transform duration-500 group-hover:-translate-y-[0.3cqw] group-hover:scale-110" />
                  <p className="mt-[1.05cqw] text-[0.73cqw] font-medium leading-[1.34] text-white">
                    {label[0]}
                    <br />
                    {label[1]}
                  </p>
                </a>
              </li>
            ))}
          </ul>

          {/* collage */}
          <div
            className="absolute right-0 top-0 h-[31cqw] w-[44.5cqw]"
            style={{ transform: `translate3d(0,${Math.min(scrollY * 0.04, 30)}px,0)` }}
          >
            <Collage className="group/collage" />
          </div>
        </div>

        {/* ============================ WHITE STRIP ============================ */}
        <div className="absolute inset-x-0 bottom-0 h-[7.4cqw] bg-white">
          <div className="flex h-full items-center pl-[2.75cqw] pr-[2.4cqw]">
            <ul className="flex flex-1 items-center">
              {STRIP.map(({ Icon, label }, i) => (
                <li key={label[0]} className="flex items-center">
                  {i > 0 && <span className="mx-[1.6cqw] h-[2.9cqw] w-px bg-ink/20" />}
                  <a
                    href="#services"
                    className="group flex items-center gap-[0.8cqw] text-ink transition-colors duration-300 hover:text-brand-600"
                  >
                    <Icon className="w-[2.1cqw] transition-transform duration-300 group-hover:-translate-y-[0.14cqw] group-hover:scale-110" />
                    <span className="whitespace-nowrap text-[0.79cqw] font-semibold leading-[1.3]">
                      {label[0]}
                      <br />
                      {label[1]}
                    </span>
                  </a>
                </li>
              ))}
            </ul>

            <div className="flex shrink-0 items-center gap-[1.6cqw] pl-[2cqw]">
              <GhanaFlag className="w-[8.4cqw] -rotate-[1.5deg] drop-shadow-[0_2px_8px_rgba(0,0,0,.2)]" />
              <div className="text-right">
                <p className="whitespace-nowrap font-script text-[2.15cqw] leading-none text-ink">Accra, Ghana</p>
                <svg viewBox="0 0 200 10" className="ml-auto mt-[0.25cqw] w-[8.2cqw]" aria-hidden="true">
                  <path d="M3 7C60 2 130 1 197 4" stroke="#0e2038" strokeWidth="2" fill="none" strokeLinecap="round" />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ============================ MOBILE / TABLET ============================ */}
      <div className="relative overflow-hidden bg-[radial-gradient(120%_100%_at_20%_0%,#143a5e_0%,#0a1c33_45%,#050f1d_100%)] lg:hidden">
        <svg
          className="pointer-events-none absolute inset-0 h-full w-full"
          viewBox="0 0 100 100"
          preserveAspectRatio="none"
          aria-hidden="true"
        >
          <defs>
            <linearGradient id="mCorner" x1="0" y1="0" x2="1" y2="1">
              <stop stopColor="#4fb3ff" />
              <stop offset="1" stopColor="#0e4c92" />
            </linearGradient>
          </defs>
          <polygon points="0,0 26,0 0,26" fill="url(#mCorner)" />
          <polygon points="0,30 30,0 33,0 0,33" fill="#8fd0ff" opacity=".5" />
          <polygon points="0,100 0,74 26,100" fill="#12395f" opacity=".85" />
          <polygon points="100,0 100,12 88,0" fill="#12395f" opacity=".5" />
        </svg>
        <div className="pointer-events-none absolute inset-0 grid-lines opacity-40" />

        <div className="relative mx-auto max-w-3xl px-6 pb-10 pt-12 sm:px-8">
          <div className="flex items-center gap-4">
            <LogoMark className="w-14 shrink-0 text-white drop-shadow-[0_4px_12px_rgba(0,0,0,.5)] sm:w-16" />
            <h1 className="font-display text-[1.65rem] font-extrabold leading-[1.12] text-white sm:text-[2.4rem]">
              RICHARD <span className="text-brand-500">ADJEI</span> MENSAH
            </h1>
          </div>

          <ul className="mt-5 flex flex-wrap items-center gap-x-3 gap-y-2 font-display text-[0.68rem] font-semibold tracking-[.16em] text-white sm:text-[0.76rem]">
            {HEADLINE.map((t, i) => (
              <li key={t} className="flex items-center gap-3">
                {i > 0 && <span className="h-3 w-px bg-white/45" />}
                {t}
              </li>
            ))}
          </ul>

          <ul className="mt-5 grid gap-2.5 text-[0.88rem] text-white sm:grid-cols-2">
            {CONTACT.map(({ Icon, text, href }) => (
              <li key={text}>
                <a
                  href={href}
                  target={href.startsWith("http") ? "_blank" : undefined}
                  rel="noreferrer"
                  className="inline-flex items-center gap-2.5 transition-colors hover:text-brand-300"
                >
                  <Icon className="w-4 shrink-0 text-brand-500" />
                  <span className="min-w-0">{text}</span>
                </a>
              </li>
            ))}
          </ul>

          <div className="mt-9 -rotate-2">
            <p className="font-script text-[2rem] leading-tight text-white sm:text-4xl">
              Building Skills
              <br />
              <span className="pl-4">for a Smarter Future</span>
            </p>
            <svg viewBox="0 0 300 16" className="mt-1 w-56" aria-hidden="true">
              <path d="M3 12C70 4 160 2 297 6" stroke="#3aa9ff" strokeWidth="3" fill="none" strokeLinecap="round" />
            </svg>
          </div>

          <ul className="mt-10 grid grid-cols-2 gap-x-3 gap-y-8 sm:grid-cols-3">
            {SERVICES.map(({ Icon, label }) => (
              <li key={label[0]} className="group flex flex-col items-center text-center">
                <Icon className="w-11 transition-transform duration-500 group-hover:-translate-y-1 group-hover:scale-110" />
                <p className="mt-2.5 text-[0.82rem] font-medium leading-snug text-white">
                  {label[0]}
                  <br />
                  {label[1]}
                </p>
              </li>
            ))}
          </ul>

          <div className="group/collage mt-11 grid grid-cols-2 overflow-hidden rounded-2xl border border-white/10 shadow-[0_24px_60px_-24px_rgba(0,0,0,.85)]">
            {PANELS.map((p) => (
              <div key={p.src} className="relative aspect-[4/3] overflow-hidden">
                <img
                  src={p.src}
                  alt={p.alt}
                  loading="lazy"
                  className="h-full w-full object-cover brightness-[.9] transition-transform duration-[1400ms] group-hover/collage:scale-110"
                />
                <div className="absolute inset-0 bg-[linear-gradient(155deg,rgba(11,42,74,.5),rgba(4,12,24,.72))] mix-blend-multiply" />
              </div>
            ))}
          </div>

          <div className="mt-9 flex items-end justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3">
              <MetaLogo className="w-9" />
              <GoogleLogo className="w-7" />
              <WhatsAppLogo className="w-7" />
              <InstagramLogo className="w-7" />
              <AnalyticsLogo className="w-7" />
            </div>
            <div className="text-right">
              <p className="font-display text-sm font-bold leading-tight text-white">
                From Learning
                <br />
                to
              </p>
              <p className="font-script text-[1.6rem] leading-tight text-brand-400">Creating Solutions</p>
            </div>
          </div>
        </div>

        {/* white strip */}
        <div className="relative bg-white">
          <div className="mx-auto grid max-w-3xl grid-cols-1 gap-y-5 px-6 py-7 sm:grid-cols-2 sm:px-8">
            {STRIP.map(({ Icon, label }) => (
              <a
                key={label[0]}
                href="#services"
                className="group flex items-center gap-3.5 text-ink transition-colors hover:text-brand-600"
              >
                <Icon className="w-8 shrink-0 transition-transform duration-300 group-hover:scale-110" />
                <span className="text-[0.92rem] font-semibold leading-tight">
                  {label[0]}
                  <br />
                  {label[1]}
                </span>
              </a>
            ))}
            <div className="flex items-center justify-between gap-4 sm:col-span-2 sm:justify-end sm:gap-8 sm:pt-2">
              <GhanaFlag className="w-28 -rotate-2 drop-shadow-[0_2px_8px_rgba(0,0,0,.18)]" />
              <div className="text-right">
                <p className="font-script text-3xl leading-none text-ink">Accra, Ghana</p>
                <svg viewBox="0 0 200 10" className="ml-auto mt-1 w-28" aria-hidden="true">
                  <path d="M3 7C60 2 130 1 197 4" stroke="#0e2038" strokeWidth="2" fill="none" strokeLinecap="round" />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
