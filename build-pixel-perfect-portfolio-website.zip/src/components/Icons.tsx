import type { SVGProps } from "react";

type Icon = (props: SVGProps<SVGSVGElement>) => React.ReactElement;

/* ------------------------------------------------------------------ */
/* Brand mark                                                          */
/* ------------------------------------------------------------------ */

export const LogoMark: Icon = (props) => (
  <svg viewBox="0 0 120 132" fill="none" aria-hidden="true" {...props}>
    <defs>
      <linearGradient id="logoLeg" x1="20" y1="58" x2="96" y2="130" gradientUnits="userSpaceOnUse">
        <stop stopColor="#74c6ff" />
        <stop offset="0.45" stopColor="#2b96f7" />
        <stop offset="1" stopColor="#1673d2" />
      </linearGradient>
    </defs>
    {/* stem + bowl (with counter) */}
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      fill="currentColor"
      d="M18 2h82v56H40v72H18V2Zm22 20v16h40V22H40Z"
    />
    {/* angled leg */}
    <path fill="url(#logoLeg)" d="M40 58h26L40 130H14l26-72Z" />
  </svg>
);

/* ------------------------------------------------------------------ */
/* Hero / service tiles                                                */
/* ------------------------------------------------------------------ */

export const CodeTile: Icon = (props) => (
  <svg viewBox="0 0 64 64" fill="none" aria-hidden="true" {...props}>
    <rect x="2" y="6" width="60" height="52" rx="12" fill="url(#g-code)" />
    <path
      d="M25 24 17 32l8 8M39 24l8 8-8 8M35 21l-6 22"
      stroke="#fff"
      strokeWidth="3.4"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <defs>
      <linearGradient id="g-code" x1="2" y1="6" x2="62" y2="58">
        <stop stopColor="#3aa9ff" />
        <stop offset="1" stopColor="#1466c8" />
      </linearGradient>
    </defs>
  </svg>
);

export const ItSupportTile: Icon = (props) => (
  <svg viewBox="0 0 64 64" fill="none" aria-hidden="true" {...props}>
    <rect x="6" y="10" width="52" height="34" rx="4" stroke="#2fe3a6" strokeWidth="3.4" />
    <path d="M2 50h60" stroke="#2fe3a6" strokeWidth="3.4" strokeLinecap="round" />
    <path d="M20 56h24" stroke="#2fe3a6" strokeWidth="3.4" strokeLinecap="round" />
    <circle cx="32" cy="26" r="5.6" stroke="#2fe3a6" strokeWidth="3" />
    <path
      d="M32 15.4v3.2M32 33.4v3.2M42.6 26h-3.2M24.6 26h-3.2M39.6 18.4l-2.3 2.3M26.7 31.3l-2.3 2.3M39.6 33.6l-2.3-2.3M26.7 20.7l-2.3-2.3"
      stroke="#2fe3a6"
      strokeWidth="3"
      strokeLinecap="round"
    />
  </svg>
);

export const StemTile: Icon = (props) => (
  <svg viewBox="0 0 64 64" fill="none" aria-hidden="true" {...props}>
    <path d="M32 10 4 22l28 12 28-12-28-12z" fill="#ffd21f" />
    <path d="M14 30.5v13.2c0 4.5 8 8.1 18 8.1s18-3.6 18-8.1V30.5l-18 7.8-18-7.8z" fill="#ffd21f" opacity=".92" />
    <path d="M56 24v18" stroke="#ffd21f" strokeWidth="3.4" strokeLinecap="round" />
    <circle cx="56" cy="45" r="3.2" fill="#ffd21f" />
  </svg>
);

export const MarketingTile: Icon = (props) => (
  <svg viewBox="0 0 64 64" fill="none" aria-hidden="true" {...props}>
    <path d="M40 10 18 22H10a4 4 0 0 0-4 4v8a4 4 0 0 0 4 4h8l22 12V10z" fill="#a855f7" />
    <path d="M18 38v14a5 5 0 0 0 5 5h3l-2-19h-6z" fill="#a855f7" />
    <path
      d="M47 20.5a15 15 0 0 1 0 19M53 14a23 23 0 0 1 0 32"
      stroke="#a855f7"
      strokeWidth="3.4"
      strokeLinecap="round"
    />
  </svg>
);

export const DesignTile: Icon = (props) => (
  <svg viewBox="0 0 64 64" fill="none" aria-hidden="true" {...props}>
    <path
      d="M52 36v14a8 8 0 0 1-8 8H14a8 8 0 0 1-8-8V20a8 8 0 0 1 8-8h14"
      stroke="#ff3d8b"
      strokeWidth="3.6"
      strokeLinecap="round"
    />
    <path d="M23 41.5 51.5 13a5.6 5.6 0 0 1 8 0l1.5 1.5a5.6 5.6 0 0 1 0 8L32.5 51 22 53l1-11.5z" fill="#ff3d8b" />
  </svg>
);

export const AiTile: Icon = (props) => (
  <svg viewBox="0 0 64 64" fill="none" aria-hidden="true" {...props}>
    <rect x="14" y="14" width="36" height="36" rx="7" stroke="#2fe3a6" strokeWidth="3.4" />
    <rect x="25" y="25" width="14" height="14" rx="3" fill="#2fe3a6" />
    <path
      d="M22 14V5M32 14V5M42 14V5M22 59v-9M32 59v-9M42 59v-9M14 22H5M14 32H5M14 42H5M59 22h-9M59 32h-9M59 42h-9"
      stroke="#2fe3a6"
      strokeWidth="3"
      strokeLinecap="round"
    />
  </svg>
);

/* ------------------------------------------------------------------ */
/* Bottom strip line icons                                             */
/* ------------------------------------------------------------------ */

const line = {
  stroke: "currentColor",
  strokeWidth: 1.9,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
  fill: "none",
};

export const LaptopIcon: Icon = (props) => (
  <svg viewBox="0 0 24 24" aria-hidden="true" {...props}>
    <rect x="3.2" y="4.6" width="17.6" height="11.6" rx="1.8" {...line} />
    <path d="M1.6 19.4h20.8" {...line} />
  </svg>
);

export const ToolsIcon: Icon = (props) => (
  <svg viewBox="0 0 24 24" aria-hidden="true" {...props}>
    <path
      d="M14.7 6.3a4.2 4.2 0 0 1 5.5-5.5l-3 3 .9 2.1 2.1.9 3-3a4.2 4.2 0 0 1-5.5 5.5L7.4 19.6a2.1 2.1 0 1 1-3-3L14.7 6.3z"
      {...line}
    />
    <path d="M3.4 3.4 6 6M20.6 20.6 18 18" {...line} />
    <path d="M17.8 3.2 20.8 6.2" {...line} />
  </svg>
);

export const CartIcon: Icon = (props) => (
  <svg viewBox="0 0 24 24" aria-hidden="true" {...props}>
    <path d="M2 3.2h2.6l2.3 11.1h11.3l2.4-8.2H6" {...line} />
    <circle cx="9" cy="19.6" r="1.7" {...line} />
    <circle cx="17.4" cy="19.6" r="1.7" {...line} />
  </svg>
);

export const ShieldIcon: Icon = (props) => (
  <svg viewBox="0 0 24 24" aria-hidden="true" {...props}>
    <path d="M12 2.4 4.4 5.5v6.1c0 4.6 3.2 8.6 7.6 10 4.4-1.4 7.6-5.4 7.6-10V5.5L12 2.4z" {...line} />
    <path d="m8.9 11.9 2.2 2.2 4-4.2" {...line} />
  </svg>
);

export const CloudGearIcon: Icon = (props) => (
  <svg viewBox="0 0 24 24" aria-hidden="true" {...props}>
    <path
      d="M7.3 18.4A4.6 4.6 0 0 1 6.6 9.3a5.6 5.6 0 0 1 10.8.6 4.3 4.3 0 0 1-.6 8.5"
      {...line}
    />
    <circle cx="12.4" cy="16.4" r="2.4" {...line} />
    <path
      d="M12.4 12.6v1.4M12.4 18.8v1.4M16.2 16.4h-1.4M9.9 16.4H8.5M15.2 13.6l-1 1M10.6 18.2l-1 1M15.2 19.2l-1-1M10.6 14.6l-1-1"
      {...line}
    />
  </svg>
);

/* ------------------------------------------------------------------ */
/* Contact + UI icons                                                  */
/* ------------------------------------------------------------------ */

export const PinIcon: Icon = (props) => (
  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...props}>
    <path d="M12 2.2c-3.9 0-7 3.1-7 7 0 5.1 6 12.1 6.3 12.4.4.4 1 .4 1.4 0 .3-.3 6.3-7.3 6.3-12.4 0-3.9-3.1-7-7-7zm0 9.6a2.7 2.7 0 1 1 0-5.4 2.7 2.7 0 0 1 0 5.4z" />
  </svg>
);

export const PhoneIcon: Icon = (props) => (
  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...props}>
    <path d="M6.6 2.6 8.9 2c.6-.2 1.2.1 1.5.6l1.7 3.3c.3.5.2 1.2-.2 1.6l-1.5 1.5c1 2 2.6 3.7 4.7 4.7l1.5-1.5c.4-.4 1.1-.5 1.6-.2l3.3 1.7c.5.3.8.9.6 1.5l-.6 2.3c-.2.8-.9 1.3-1.7 1.3A17.4 17.4 0 0 1 5.3 4.3c0-.8.5-1.5 1.3-1.7z" />
  </svg>
);

export const MailIcon: Icon = (props) => (
  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...props}>
    <path d="M3.4 4.6h17.2c1 0 1.8.8 1.8 1.8v.4l-10.4 6-10.4-6v-.4c0-1 .8-1.8 1.8-1.8zM1.6 9.1l10 5.8c.25.14.55.14.8 0l10-5.8v8.5c0 1-.8 1.8-1.8 1.8H3.4c-1 0-1.8-.8-1.8-1.8V9.1z" />
  </svg>
);

export const ArrowIcon: Icon = (props) => (
  <svg viewBox="0 0 24 24" fill="none" aria-hidden="true" {...props}>
    <path d="M4 12h15m0 0-5.5-5.5M19 12l-5.5 5.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const MenuIcon: Icon = (props) => (
  <svg viewBox="0 0 24 24" fill="none" aria-hidden="true" {...props}>
    <path d="M4 7h16M4 12h16M4 17h16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

export const CloseIcon: Icon = (props) => (
  <svg viewBox="0 0 24 24" fill="none" aria-hidden="true" {...props}>
    <path d="M6 6l12 12M18 6 6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

export const CheckIcon: Icon = (props) => (
  <svg viewBox="0 0 24 24" fill="none" aria-hidden="true" {...props}>
    <path d="m5 12.5 4.5 4.5L19 7" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

/* ------------------------------------------------------------------ */
/* Tech stack logos (hero collage)                                     */
/* ------------------------------------------------------------------ */

export const ReactLogo: Icon = (props) => (
  <svg viewBox="0 0 64 64" fill="none" aria-hidden="true" {...props}>
    <circle cx="32" cy="32" r="4.6" fill="#61dafb" />
    <g stroke="#61dafb" strokeWidth="2.6" fill="none">
      <ellipse cx="32" cy="32" rx="26" ry="10.4" />
      <ellipse cx="32" cy="32" rx="26" ry="10.4" transform="rotate(60 32 32)" />
      <ellipse cx="32" cy="32" rx="26" ry="10.4" transform="rotate(120 32 32)" />
    </g>
  </svg>
);

export const TSLogo: Icon = (props) => (
  <svg viewBox="0 0 64 64" aria-hidden="true" {...props}>
    <rect width="64" height="64" rx="10" fill="#3178c6" />
    <text
      x="32"
      y="43"
      textAnchor="middle"
      fontFamily="Montserrat, Poppins, sans-serif"
      fontSize="27"
      fontWeight="800"
      fill="#fff"
    >
      TS
    </text>
  </svg>
);

export const NodeLogo: Icon = (props) => (
  <svg viewBox="0 0 150 56" aria-hidden="true" {...props}>
    <g fill="#8cc84b">
      <path d="M75 12.5 66 17.6v10.2l9 5.1 9-5.1V17.6l-9-5.1z" opacity=".95" />
      <text
        x="96"
        y="38"
        fontFamily="Poppins, sans-serif"
        fontSize="30"
        fontWeight="600"
        letterSpacing="-1"
        fill="#fff"
      >
        node
      </text>
      <text x="112" y="47" fontFamily="Poppins, sans-serif" fontSize="9" fontWeight="600" fill="#8cc84b">
        JS
      </text>
    </g>
  </svg>
);

export const PythonLogo: Icon = (props) => (
  <svg viewBox="0 0 48 48" aria-hidden="true" {...props}>
    <path
      d="M23.8 2c-3.2 0-6 .3-8.4.9-3.9 1-4.6 3-4.6 6v3.3h12v1.6H6.6c-3 0-5.6 1.8-6.4 5.2-.9 3.9-1 6.4 0 10.4.7 3 2.4 5.2 5.4 5.2h3.9v-4.3c0-3.3 2.9-6.2 6.3-6.2h9.5c2.8 0 5-2.3 5-5.1V8.9c0-2.7-2.3-4.8-5-5.2A31 31 0 0 0 23.8 2zm-6.1 4.3c1.1 0 1.9.9 1.9 2s-.8 2-1.9 2-2-.9-2-2 .9-2 2-2z"
      fill="#3c7cb8"
    />
    <path
      d="M24.2 46c3.2 0 6-.3 8.4-.9 3.9-1 4.6-3 4.6-6v-3.3h-12v-1.6h16.2c3 0 5.6-1.8 6.4-5.2.9-3.9 1-6.4 0-10.4-.7-3-2.4-5.2-5.4-5.2h-3.9v4.3c0 3.3-2.9 6.2-6.3 6.2h-9.5c-2.8 0-5 2.3-5 5.1v9.5c0 2.7 2.3 4.8 5 5.2 1.1.2 2.2.3 1.5.3zm6.1-4.3c-1.1 0-1.9-.9-1.9-2s.8-2 1.9-2 2 .9 2 2-.9 2-2 2z"
      fill="#ffd43b"
    />
  </svg>
);

export const FlaskLogo: Icon = (props) => (
  <svg viewBox="0 0 150 56" aria-hidden="true" {...props}>
    <path
      d="M22 6h8v3h-2v9l10 17a5 5 0 0 1-4.3 7.5H18.3A5 5 0 0 1 14 35l10-17V9h-2V6z"
      fill="none"
      stroke="#fff"
      strokeWidth="2.6"
      strokeLinejoin="round"
    />
    <path d="M18.5 31h15l4.2 7.1a2.4 2.4 0 0 1-2 3.6H16.3a2.4 2.4 0 0 1-2-3.6l4.2-7.1z" fill="#fff" />
    <text
      x="42"
      y="40"
      fontFamily="Poppins, sans-serif"
      fontSize="26"
      fontWeight="600"
      fill="#fff"
      letterSpacing="-0.5"
    >
      Flask
    </text>
  </svg>
);

/* ------------------------------------------------------------------ */
/* Social logos (hero collage)                                         */
/* ------------------------------------------------------------------ */

export const MetaLogo: Icon = (props) => (
  <svg viewBox="0 0 48 32" fill="none" aria-hidden="true" {...props}>
    <path
      d="M3 26c0-8 5-22 10-22s7 8 11 16c3 6 5 6 7 2 2.6-5 4-8 6-8 3 0 5 5 5 8"
      stroke="#0082fb"
      strokeWidth="5.4"
      strokeLinecap="round"
    />
    <path
      d="M3 26c0-8 5-22 10-22s7 8 11 16c3 6 5 6 7 2 2.6-5 4-8 6-8 3 0 5 5 5 8"
      stroke="url(#g-meta)"
      strokeWidth="5.4"
      strokeLinecap="round"
    />
    <defs>
      <linearGradient id="g-meta" x1="3" y1="26" x2="42" y2="4">
        <stop stopColor="#00c6ff" />
        <stop offset="1" stopColor="#0068ff" />
      </linearGradient>
    </defs>
  </svg>
);

export const GoogleLogo: Icon = (props) => (
  <svg viewBox="0 0 24 24" aria-hidden="true" {...props}>
    <path
      fill="#4285F4"
      d="M23.5 12.27c0-.79-.07-1.55-.2-2.27H12v4.51h6.45a5.52 5.52 0 0 1-2.39 3.62v3h3.87c2.26-2.08 3.57-5.15 3.57-8.86z"
    />
    <path
      fill="#34A853"
      d="M12 24c3.24 0 5.96-1.08 7.93-2.87l-3.87-3c-1.08.72-2.45 1.15-4.06 1.15-3.13 0-5.78-2.11-6.73-4.96H1.29v3.1A12 12 0 0 0 12 24z"
    />
    <path fill="#FBBC05" d="M5.27 14.32a7.2 7.2 0 0 1 0-4.63v-3.1H1.29a12 12 0 0 0 0 10.83l3.98-3.1z" />
    <path
      fill="#EA4335"
      d="M12 4.72c1.76 0 3.34.61 4.59 1.8l3.44-3.44A11.98 11.98 0 0 0 1.29 6.59l3.98 3.1C6.22 6.83 8.87 4.72 12 4.72z"
    />
  </svg>
);

export const WhatsAppLogo: Icon = (props) => (
  <svg viewBox="0 0 24 24" aria-hidden="true" {...props}>
    <path
      fill="#25D366"
      d="M12 .8C5.8.8.8 5.8.8 12c0 2 .5 3.9 1.5 5.6L.8 23.2l5.7-1.5A11.2 11.2 0 0 0 12 23.2c6.2 0 11.2-5 11.2-11.2S18.2.8 12 .8z"
    />
    <path
      fill="#fff"
      d="M17.5 14.3c-.2-.1-1.6-.8-1.9-.9-.2-.1-.4-.1-.6.1l-.8 1c-.1.2-.3.2-.5.1a8.1 8.1 0 0 1-2.4-1.5 8.8 8.8 0 0 1-1.6-2c-.2-.3 0-.4.1-.6l.6-.7c.1-.2.2-.3.3-.5v-.5l-.9-2c-.2-.5-.4-.4-.6-.4h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.5s1.1 2.9 1.2 3.1c.1.2 2 3.2 4.9 4.4 2.9 1.1 3.2.9 3.8.8.6 0 1.9-.7 2.1-1.5.3-.7.3-1.3.2-1.5 0 0-.2-.1-.5-.3z"
    />
  </svg>
);

export const InstagramLogo: Icon = (props) => (
  <svg viewBox="0 0 24 24" aria-hidden="true" {...props}>
    <defs>
      <linearGradient id="g-ig" x1="2" y1="22" x2="22" y2="2">
        <stop stopColor="#FFD600" />
        <stop offset=".4" stopColor="#FF0169" />
        <stop offset="1" stopColor="#7638FA" />
      </linearGradient>
    </defs>
    <rect width="24" height="24" rx="6.4" fill="url(#g-ig)" />
    <rect x="4.4" y="4.4" width="15.2" height="15.2" rx="4.6" fill="none" stroke="#fff" strokeWidth="1.9" />
    <circle cx="12" cy="12" r="3.7" fill="none" stroke="#fff" strokeWidth="1.9" />
    <circle cx="16.9" cy="7.1" r="1.2" fill="#fff" />
  </svg>
);

export const AnalyticsLogo: Icon = (props) => (
  <svg viewBox="0 0 24 24" aria-hidden="true" {...props}>
    <defs>
      <linearGradient id="g-an" x1="0" y1="0" x2="24" y2="24">
        <stop stopColor="#4facfe" />
        <stop offset="1" stopColor="#1a6ef5" />
      </linearGradient>
    </defs>
    <rect width="24" height="24" rx="6.4" fill="url(#g-an)" />
    <path d="M6.4 16.6v-3.4M10.4 16.6v-6M14.4 16.6v-4.4" stroke="#fff" strokeWidth="2" strokeLinecap="round" />
    <path d="M6.6 9.6 11 6.2l3 2.2 4.4-3" stroke="#fff" strokeWidth="1.9" strokeLinecap="round" fill="none" />
    <circle cx="18.6" cy="5.2" r="1.5" fill="#fff" />
  </svg>
);

/* ------------------------------------------------------------------ */
/* Ghana flag (painted brush style)                                    */
/* ------------------------------------------------------------------ */

export const GhanaFlag: Icon = (props) => (
  <svg viewBox="0 0 180 62" aria-hidden="true" {...props}>
    <g>
      <path
        d="M4 6.5c30-3.4 60-5.4 92-4.6 26 .7 53 2.6 80 5.6-.6 6.4-1 13-1.2 19.6H5.4C5 20.6 4.6 13.4 4 6.5z"
        fill="#e0301e"
      />
      <path
        d="M5.4 27.1h169.4c-.2 4.4-.2 8.8 0 13.2H5.2c.2-4.4.3-8.8.2-13.2z"
        fill="#fcd116"
      />
      <path
        d="M5.2 40.3h169.6c-.4 6.4-1 12.8-2 19.2-27 2.6-54 3.6-81 3.1-29-.5-58-2.2-86.6-5.1-.7-5.7-1.1-11.4-1.2-17.2z"
        fill="#006b3f"
      />
      <path
        d="M90 16.5l3.3 10.2h10.7l-8.6 6.3 3.3 10.2-8.7-6.3-8.7 6.3 3.3-10.2-8.6-6.3H86.7L90 16.5z"
        fill="#000"
      />
    </g>
  </svg>
);
