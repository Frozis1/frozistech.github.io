import { useState } from "react";
import { ArrowIcon, CheckIcon, GhanaFlag, LogoMark, MailIcon, PhoneIcon, PinIcon, WhatsAppLogo, InstagramLogo, GoogleLogo, MetaLogo } from "./Icons";
import { Eyebrow } from "./ui";

const METHODS = [
  {
    Icon: PhoneIcon,
    label: "Call or WhatsApp",
    value: "+233 546 093 300",
    href: "tel:+233546093300",
    note: "Mon – Sat · 8:00 – 19:00 GMT",
  },
  {
    Icon: MailIcon,
    label: "Email",
    value: "richardadjeimenz24@gmail.com",
    href: "mailto:richardadjeimenz24@gmail.com",
    note: "Replies within one business day",
  },
  {
    Icon: PinIcon,
    label: "Workshop & service area",
    value: "Greater Accra, Ghana",
    href: "https://maps.google.com/?q=Accra,+Ghana",
    note: "On-site visits across the capital",
  },
];

const SERVICE_OPTIONS = [
  "Web & mobile application",
  "Computer repair or upgrade",
  "STEM / robotics program",
  "Digital marketing & ads",
  "Graphic design & branding",
  "AI automation & workflow",
  "Networking & cybersecurity",
  "Device sales & accessories",
];

export default function Contact() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", service: SERVICE_OPTIONS[0], message: "" });

  const update = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  return (
    <section id="contact" className="relative overflow-hidden py-20 sm:py-28">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(90%_60%_at_75%_10%,rgba(30,143,245,.16),transparent_65%)]" />
      <div className="pointer-events-none absolute inset-0 grid-lines opacity-25" />

      <div className="relative mx-auto max-w-[1200px] px-5 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
          {/* left */}
          <div>
            <div className="reveal" data-dir="up">
              <Eyebrow>Let's talk</Eyebrow>
            </div>
            <p className="reveal mt-5 font-script text-3xl leading-none text-brand-400" data-dir="up">
              Building skills for a smarter future
            </p>
            <h2
              className="reveal mt-2 font-display text-3xl font-extrabold leading-[1.12] text-white sm:text-4xl"
              data-dir="up"
              style={{ transitionDelay: "80ms" }}
            >
              Tell me what needs to <span className="text-gradient-brand">work better</span>
            </h2>
            <p className="reveal mt-4 text-[0.98rem] leading-relaxed text-white/60" data-dir="up" style={{ transitionDelay: "140ms" }}>
              Send a note about the device, the class or the project and I'll come back with a clear plan, timeline and
              price. No jargon, no surprises.
            </p>

            <ul className="mt-9 space-y-3">
              {METHODS.map(({ Icon, label, value, href, note }, i) => (
                <li key={label} className="reveal" data-dir="left" style={{ transitionDelay: `${i * 90}ms` }}>
                  <a
                    href={href}
                    target={href.startsWith("http") ? "_blank" : undefined}
                    rel="noreferrer"
                    className="group flex items-center gap-4 rounded-xl border border-white/10 bg-navy-850/60 p-4 transition-all duration-400 hover:-translate-y-0.5 hover:border-brand-400/40 hover:bg-navy-800/70"
                  >
                    <span className="grid h-11 w-11 shrink-0 place-items-center rounded-lg bg-brand-500/12 text-brand-400 transition-colors duration-300 group-hover:bg-brand-500 group-hover:text-white">
                      <Icon className="w-5" />
                    </span>
                    <span className="min-w-0">
                      <span className="block text-[0.66rem] font-semibold uppercase tracking-[.18em] text-white/40">
                        {label}
                      </span>
                      <span className="block truncate text-[0.95rem] font-semibold text-white">{value}</span>
                      <span className="block text-[0.74rem] text-white/40">{note}</span>
                    </span>
                    <ArrowIcon className="ml-auto w-4 shrink-0 text-white/25 transition-all duration-300 group-hover:translate-x-1 group-hover:text-brand-400" />
                  </a>
                </li>
              ))}
            </ul>

            <div className="reveal mt-8 flex items-center gap-3" data-dir="up">
              <span className="text-[0.68rem] font-semibold uppercase tracking-[.18em] text-white/35">Find me on</span>
              <div className="flex items-center gap-2.5">
                {[WhatsAppLogo, MetaLogo, InstagramLogo, GoogleLogo].map((Icon, i) => (
                  <a
                    key={i}
                    href="#contact"
                    aria-label="Social profile"
                    className="grid h-9 w-9 place-items-center rounded-lg border border-white/10 bg-navy-850/70 transition-all duration-300 hover:-translate-y-1 hover:border-brand-400/50"
                  >
                    <Icon className="w-4.5" />
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* form */}
          <div className="reveal relative" data-dir="right">
            <div className="pointer-events-none absolute -inset-3 rounded-3xl bg-[linear-gradient(140deg,rgba(30,143,245,.35),transparent_55%)] opacity-60 blur-xl" />
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setSent(true);
              }}
              className="relative rounded-2xl border border-white/10 bg-navy-850/80 p-6 backdrop-blur-md sm:p-8"
            >
              <div className="grid gap-4 sm:grid-cols-2">
                <label className="block">
                  <span className="mb-1.5 block text-[0.68rem] font-semibold uppercase tracking-[.18em] text-white/40">
                    Your name
                  </span>
                  <input
                    required
                    value={form.name}
                    onChange={update("name")}
                    placeholder="Ama Mensah"
                    className="w-full rounded-xl border border-white/12 bg-navy-900/70 px-4 py-3 text-sm text-white placeholder-white/25 outline-none transition-colors focus:border-brand-400"
                  />
                </label>
                <label className="block">
                  <span className="mb-1.5 block text-[0.68rem] font-semibold uppercase tracking-[.18em] text-white/40">
                    Email or phone
                  </span>
                  <input
                    required
                    value={form.email}
                    onChange={update("email")}
                    placeholder="you@example.com"
                    className="w-full rounded-xl border border-white/12 bg-navy-900/70 px-4 py-3 text-sm text-white placeholder-white/25 outline-none transition-colors focus:border-brand-400"
                  />
                </label>
              </div>

              <label className="mt-4 block">
                <span className="mb-1.5 block text-[0.68rem] font-semibold uppercase tracking-[.18em] text-white/40">
                  What do you need?
                </span>
                <select
                  value={form.service}
                  onChange={update("service")}
                  className="w-full appearance-none rounded-xl border border-white/12 bg-navy-900/70 px-4 py-3 text-sm text-white outline-none transition-colors focus:border-brand-400"
                >
                  {SERVICE_OPTIONS.map((o) => (
                    <option key={o} className="bg-navy-900">
                      {o}
                    </option>
                  ))}
                </select>
              </label>

              <label className="mt-4 block">
                <span className="mb-1.5 block text-[0.68rem] font-semibold uppercase tracking-[.18em] text-white/40">
                  Details
                </span>
                <textarea
                  required
                  rows={5}
                  value={form.message}
                  onChange={update("message")}
                  placeholder="Tell me about the device, the school, or the idea…"
                  className="w-full resize-none rounded-xl border border-white/12 bg-navy-900/70 px-4 py-3 text-sm leading-relaxed text-white placeholder-white/25 outline-none transition-colors focus:border-brand-400"
                />
              </label>

              <button
                type="submit"
                className="group mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-brand-500 px-6 py-3.5 text-sm font-semibold text-white transition-all duration-300 hover:bg-brand-400 hover:shadow-glow"
              >
                {sent ? "Message sent — thank you!" : "Send message"}
                {sent ? <CheckIcon className="w-4" /> : <ArrowIcon className="w-4 transition-transform duration-300 group-hover:translate-x-1" />}
              </button>

              {sent && (
                <p className="mt-4 rounded-xl border border-aqua/30 bg-aqua/10 px-4 py-3 text-[0.82rem] text-aqua">
                  Thanks {form.name.split(" ")[0] || "there"} — your note about “{form.service.toLowerCase()}” is in.
                  I'll reply from richardadjeimenz24@gmail.com within one business day.
                </p>
              )}

              <p className="mt-4 text-center text-[0.72rem] text-white/35">
                Prefer to talk? Call{" "}
                <a href="tel:+233546093300" className="text-brand-300 hover:underline">
                  +233 546 093 300
                </a>
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="relative border-t border-white/10 bg-navy-950">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-brand-400/50 to-transparent" />
      <div className="mx-auto max-w-[1200px] px-5 py-14 sm:px-8">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3">
              <LogoMark className="w-10 text-white" />
              <span className="font-display text-lg font-extrabold text-white">
                RICHARD <span className="text-brand-500">ADJEI</span> MENSAH
              </span>
            </div>
            <p className="mt-4 max-w-sm text-[0.9rem] leading-relaxed text-white/45">
              Technology & IT support, STEM education and digital services from Greater Accra, Ghana — taking ideas from
              learning to creating solutions.
            </p>
            <div className="mt-6 flex items-center gap-5">
              <GhanaFlag className="w-24 -rotate-2 drop-shadow-[0_2px_8px_rgba(0,0,0,.4)]" />
              <div>
                <p className="font-script text-3xl leading-none text-white">Accra, Ghana</p>
                <svg viewBox="0 0 200 10" className="mt-1.5 w-24" aria-hidden="true">
                  <path d="M3 7C60 2 130 1 197 4" stroke="#3aa9ff" strokeWidth="2" fill="none" strokeLinecap="round" />
                </svg>
              </div>
            </div>
          </div>

          <nav aria-label="Footer">
            <h3 className="font-display text-[0.72rem] font-bold uppercase tracking-[.2em] text-white/40">Explore</h3>
            <ul className="mt-4 space-y-2.5 text-[0.9rem] text-white/60">
              {[
                ["About", "#about"],
                ["Services", "#services"],
                ["Computing scales", "#scales"],
                ["Selected work", "#work"],
                ["Contact", "#contact"],
              ].map(([label, href]) => (
                <li key={href}>
                  <a href={href} className="transition-colors duration-300 hover:text-brand-300">
                    {label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <div>
            <h3 className="font-display text-[0.72rem] font-bold uppercase tracking-[.2em] text-white/40">Contact</h3>
            <ul className="mt-4 space-y-2.5 text-[0.9rem] text-white/60">
              <li>
                <a href="tel:+233546093300" className="transition-colors hover:text-brand-300">
                  +233 546 093 300
                </a>
              </li>
              <li>
                <a href="mailto:richardadjeimenz24@gmail.com" className="break-all transition-colors hover:text-brand-300">
                  richardadjeimenz24@gmail.com
                </a>
              </li>
              <li>Greater Accra, Ghana</li>
              <li>Mon – Sat · 8:00 – 19:00 GMT</li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-white/10 pt-6 text-[0.78rem] text-white/35 sm:flex-row">
          <p>© {new Date().getFullYear()} Richard Adjei Mensah. All rights reserved.</p>
          <p className="font-script text-xl text-brand-400">Building skills for a smarter future</p>
        </div>
      </div>
    </footer>
  );
}
