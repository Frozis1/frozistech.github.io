import { AiTile, ArrowIcon, CartIcon, CloudGearIcon, CodeTile, DesignTile, ItSupportTile, LaptopIcon, MarketingTile, ShieldIcon, StemTile, ToolsIcon } from "./Icons";
import { SectionHeading } from "./ui";

const CARDS = [
  {
    Icon: CodeTile,
    title: "Coding & Programming",
    copy: "Custom websites, web apps and dashboards built with React, TypeScript and Flask — fast, responsive and easy to hand over.",
    tags: ["Web apps", "Dashboards", "APIs"],
  },
  {
    Icon: ItSupportTile,
    title: "IT Support & Computer Repairs",
    copy: "Diagnostics, board-level repair, upgrades, OS reinstalls and preventive maintenance for homes, schools and offices.",
    tags: ["Repairs", "Upgrades", "Maintenance"],
  },
  {
    Icon: StemTile,
    title: "STEM Education & Robotics",
    copy: "Project-based coding, robotics and electronics clubs with full curriculum, kits and facilitator training for schools.",
    tags: ["Curriculum", "Robotics", "Clubs"],
  },
  {
    Icon: MarketingTile,
    title: "Digital Marketing & Paid Ads",
    copy: "Campaign strategy, Meta and Google ads, landing pages and reporting that turns attention into paying customers.",
    tags: ["Meta Ads", "Google Ads", "Funnels"],
  },
  {
    Icon: DesignTile,
    title: "Graphic Design & Creative Services",
    copy: "Brand identity, print and social design systems that stay consistent from a business card to a billboard.",
    tags: ["Branding", "Print", "Social kits"],
  },
  {
    Icon: AiTile,
    title: "AI Automation & Tools",
    copy: "Workflow automation, AI assistants and integrations that remove repetitive admin from your team's week.",
    tags: ["Automation", "Chatbots", "Integrations"],
  },
];

const DELIVERY = [
  { Icon: LaptopIcon, label: ["Web & Mobile", "Applications"] },
  { Icon: ToolsIcon, label: ["Computer Repairs", "& Upgrades"] },
  { Icon: CartIcon, label: ["Device Sales", "& Accessories"] },
  { Icon: ShieldIcon, label: ["Networking &", "Cybersecurity"] },
  { Icon: CloudGearIcon, label: ["AI Automation", "& Workflow Support"] },
];

export default function Services() {
  return (
    <section id="services" className="relative overflow-hidden py-20 sm:py-28">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(80%_50%_at_50%_0%,rgba(23,57,95,.5),transparent_70%)]" />

      <div className="relative mx-auto max-w-[1200px] px-5 sm:px-8">
        <SectionHeading
          align="center"
          eyebrow="What I do"
          script="six ways we can work together"
          title="Services built around"
          accent="real problems"
          copy="Whether it's a machine that won't boot, a classroom that needs a curriculum, or a business that needs to be found online — same person, same standard."
        />

        <ul className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {CARDS.map(({ Icon, title, copy, tags }, i) => (
            <li
              key={title}
              className="reveal group relative overflow-hidden rounded-2xl border border-white/10 bg-navy-850/60 p-6 backdrop-blur-sm transition-all duration-500 hover:-translate-y-1.5 hover:border-brand-400/40 hover:shadow-glow sm:p-7"
              data-dir="up"
              style={{ transitionDelay: `${(i % 3) * 90}ms` }}
            >
              <div className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full bg-brand-500/0 blur-3xl transition-all duration-700 group-hover:bg-brand-500/25" />
              <Icon className="w-12 transition-transform duration-500 group-hover:-translate-y-1 group-hover:scale-110" />
              <h3 className="mt-5 font-display text-lg font-bold leading-snug text-white">{title}</h3>
              <p className="mt-2.5 text-[0.88rem] leading-relaxed text-white/55">{copy}</p>
              <ul className="mt-5 flex flex-wrap gap-2">
                {tags.map((t) => (
                  <li
                    key={t}
                    className="rounded-full border border-white/10 px-3 py-1 text-[0.68rem] font-semibold uppercase tracking-[.1em] text-white/45 transition-colors group-hover:border-brand-400/30 group-hover:text-brand-300"
                  >
                    {t}
                  </li>
                ))}
              </ul>
              <a
                href="#contact"
                className="mt-6 inline-flex items-center gap-2 text-[0.8rem] font-semibold text-brand-400 opacity-0 transition-all duration-500 group-hover:opacity-100"
              >
                Request this service
                <ArrowIcon className="w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </a>
            </li>
          ))}
        </ul>

        {/* delivery band */}
        <div className="reveal mt-10 rounded-2xl border border-white/10 bg-white p-6 sm:p-8" data-dir="up">
          <div className="flex flex-wrap items-baseline justify-between gap-3">
            <h3 className="font-display text-lg font-extrabold text-ink">Delivered end to end</h3>
            <p className="font-script text-2xl text-ink/70">one call, one invoice</p>
          </div>
          <ul className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-5 lg:divide-x lg:divide-ink/10">
            {DELIVERY.map(({ Icon, label }) => (
              <li
                key={label[0]}
                className="group flex items-center gap-3.5 text-ink transition-colors duration-300 hover:text-brand-600 lg:px-4"
              >
                <Icon className="w-9 shrink-0 transition-transform duration-300 group-hover:-translate-y-1 group-hover:scale-110" />
                <span className="text-[0.88rem] font-semibold leading-tight">
                  {label[0]}
                  <br />
                  {label[1]}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
