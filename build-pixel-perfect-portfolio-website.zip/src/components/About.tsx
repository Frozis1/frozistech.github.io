import { ArrowIcon, CheckIcon, GhanaFlag, PinIcon } from "./Icons";
import { Eyebrow, Stat } from "./ui";
import { HAS_PORTRAIT, PORTRAIT_SRC, PROFILE } from "../lib/profile";

const FACTS = [
  "8+ years supporting schools, SMEs and creators",
  "On-site in Greater Accra · remote everywhere",
  "Curriculum-led STEM & robotics facilitator",
  "Fluent in English and Twi",
];

export default function About() {
  return (
    <section id="about" className="relative overflow-hidden py-20 sm:py-28">
      <div className="pointer-events-none absolute -left-40 top-24 h-96 w-96 rounded-full bg-brand-600/15 blur-[120px]" />
      <div className="pointer-events-none absolute inset-0 grid-lines opacity-30" />

      <div className="relative mx-auto grid max-w-[1200px] items-center gap-12 px-5 sm:px-8 lg:grid-cols-[0.85fr_1fr] lg:gap-16">
        {/* portrait */}
        <div className="reveal relative" data-dir="left">
          <div className="relative">
            <div
              className="absolute -inset-3 bg-[linear-gradient(140deg,rgba(30,143,245,.55),transparent_60%)] opacity-70 blur-xl"
              aria-hidden="true"
            />
            <div className="group relative overflow-hidden rounded-2xl border border-white/10 bg-[#0c1f36]">
              {HAS_PORTRAIT ? (
                <>
                  <img
                    src={PORTRAIT_SRC}
                    alt={`${PROFILE.name} — ${PROFILE.roles}`}
                    loading="lazy"
                    className="aspect-[4/5] w-full object-cover object-top transition-transform duration-[1400ms] ease-out group-hover:scale-[1.04]"
                  />
                  <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(180deg,rgba(30,143,245,.1)_0%,transparent_38%,rgba(5,15,29,.6)_100%)]" />
                  <div
                    className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-700 group-hover:opacity-100"
                    style={{
                      background:
                        "linear-gradient(140deg,rgba(58,169,255,.2) 0%,transparent 45%,transparent 100%)",
                    }}
                  />
                  <div className="absolute inset-x-4 bottom-4 flex items-center gap-3 rounded-xl border border-white/12 bg-navy-900/80 px-4 py-3 backdrop-blur-md">
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-gradient-to-br from-brand-400 to-brand-600 font-display text-base font-extrabold text-white">
                      R
                    </span>
                    <span className="min-w-0">
                      <span className="block font-display text-[0.95rem] font-bold leading-tight text-white">
                        {PROFILE.name}
                      </span>
                      <span className="block truncate text-[0.78rem] text-brand-300">{PROFILE.roles}</span>
                    </span>
                  </div>
                </>
              ) : (
                <div className="relative flex aspect-[4/5] flex-col justify-between overflow-hidden bg-[radial-gradient(120%_90%_at_20%_0%,#173f66_0%,#0c2340_45%,#061120_100%)] p-6 sm:p-7">
                  <div className="pointer-events-none absolute inset-0 grid-lines opacity-40" />
                  <svg
                    className="pointer-events-none absolute inset-0 h-full w-full opacity-80"
                    viewBox="0 0 100 125"
                    preserveAspectRatio="none"
                    aria-hidden="true"
                  >
                    <polygon points="0,0 34,0 0,34" fill="#1e8ff5" opacity=".5" />
                    <polygon points="0,125 0,98 27,125" fill="#12395f" opacity=".9" />
                    <polygon points="100,0 100,16 84,0" fill="#12395f" opacity=".55" />
                  </svg>

                  <div className="relative flex items-center gap-3">
                    <span className="rounded-full border border-brand-400/30 bg-brand-500/10 px-3 py-1 text-[0.6rem] font-semibold uppercase tracking-[.2em] text-brand-300">
                      Portfolio · 2026
                    </span>
                    <span className="h-px flex-1 bg-gradient-to-r from-brand-400/40 to-transparent" />
                  </div>

                  <div className="relative">
                    <span className="relative grid h-20 w-20 place-items-center rounded-full bg-gradient-to-br from-brand-400 to-brand-700 font-display text-3xl font-extrabold text-white shadow-[0_18px_40px_-14px_rgba(30,143,245,.9)]">
                      R
                      <span className="absolute inset-0 rounded-full ring-1 ring-inset ring-white/25" />
                    </span>
                    <h3 className="mt-5 font-display text-2xl font-extrabold leading-tight text-white">
                      {PROFILE.name}
                    </h3>
                    <p className="mt-1.5 text-[0.84rem] leading-relaxed text-brand-300">{PROFILE.roles}</p>
                    <ul className="mt-5 flex flex-wrap gap-2">
                      {["Web & Apps", "STEM & Robotics", "IT Support"].map((tag) => (
                        <li
                          key={tag}
                          className="rounded-md border border-white/12 bg-white/5 px-2.5 py-1 text-[0.66rem] font-semibold tracking-wide text-white/65"
                        >
                          {tag}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="relative flex flex-wrap items-center gap-x-4 gap-y-1.5 border-t border-white/10 pt-4 text-[0.74rem] text-white/55">
                    <span className="inline-flex items-center gap-1.5">
                      <PinIcon className="w-3.5 text-brand-400" />
                      {PROFILE.location}
                    </span>
                    <a href={PROFILE.phoneHref} className="transition-colors hover:text-brand-300">
                      {PROFILE.phone}
                    </a>
                    <GhanaFlag className="ml-auto w-12 -rotate-2 drop-shadow-[0_2px_6px_rgba(0,0,0,.4)]" />
                  </div>

                  <div
                    className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-700 group-hover:opacity-100"
                    style={{
                      background:
                        "linear-gradient(140deg,rgba(58,169,255,.16) 0%,transparent 48%,transparent 100%)",
                    }}
                  />
                </div>
              )}
            </div>

            {/* floating badges */}
            <div className="floaty absolute -right-3 top-6 rounded-xl border border-white/10 bg-navy-850/90 px-4 py-3 backdrop-blur-md sm:-right-6">
              <p className="font-display text-2xl font-extrabold text-white">8+</p>
              <p className="text-[0.65rem] font-semibold uppercase tracking-[.16em] text-brand-300">Years in tech</p>
            </div>
            <div
              className="floaty absolute -left-3 bottom-24 flex items-center gap-2 rounded-xl border border-white/10 bg-navy-850/90 px-4 py-3 backdrop-blur-md sm:-left-6 sm:bottom-28"
              style={{ animationDelay: "1.4s" }}
            >
              <span className="relative flex h-2 w-2">
                <span className="ping-slow absolute inline-flex h-full w-full rounded-full bg-aqua" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-aqua" />
              </span>
              <p className="text-xs font-semibold text-white">Open to new projects</p>
            </div>
          </div>
        </div>

        {/* copy */}
        <div>
          <div className="reveal" data-dir="up">
            <Eyebrow>About me</Eyebrow>
          </div>
          <p className="reveal mt-5 font-script text-3xl leading-none text-brand-400" data-dir="up">
            Technology that actually works for people
          </p>
          <h2
            className="reveal mt-2 font-display text-3xl font-extrabold leading-[1.12] text-white sm:text-4xl"
            data-dir="up"
            style={{ transitionDelay: "80ms" }}
          >
            IT support, STEM teaching and <span className="text-gradient-brand">digital craft</span> under one roof.
          </h2>
          <p
            className="reveal mt-5 text-[0.98rem] leading-relaxed text-white/60"
            data-dir="up"
            style={{ transitionDelay: "140ms" }}
          >
            I'm Richard Adjei Mensah — a technologist, educator and creative based in Greater Accra. I keep the machines
            running, teach the next generation to build with them, and design the digital tools that make both easier.
            From a classroom robotics kit to a full web platform, I move an idea from learning to a working solution.
          </p>

          <ul className="reveal mt-7 grid gap-3 sm:grid-cols-2" data-dir="up" style={{ transitionDelay: "200ms" }}>
            {FACTS.map((f) => (
              <li key={f} className="flex items-start gap-2.5 text-sm text-white/75">
                <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-md bg-brand-500/15 text-brand-400">
                  <CheckIcon className="w-3.5" />
                </span>
                {f}
              </li>
            ))}
          </ul>

          <div className="reveal mt-9 flex flex-wrap items-center gap-4" data-dir="up" style={{ transitionDelay: "260ms" }}>
            <a
              href="#work"
              className="group inline-flex items-center gap-2 rounded-full bg-brand-500 px-6 py-3 text-sm font-semibold text-white transition-all duration-300 hover:bg-brand-400 hover:shadow-glow"
            >
              See my work
              <ArrowIcon className="w-4 transition-transform duration-300 group-hover:translate-x-1" />
            </a>
            <a
              href="#contact"
              className="inline-flex items-center gap-2 rounded-full border border-white/20 px-6 py-3 text-sm font-semibold text-white transition-colors duration-300 hover:border-brand-400 hover:text-brand-300"
            >
              Book a repair or a class
            </a>
          </div>
        </div>
      </div>

      {/* stats band */}
      <div className="relative mx-auto mt-16 max-w-[1200px] px-5 sm:px-8">
        <div className="reveal grid grid-cols-2 divide-white/10 rounded-2xl border border-white/10 bg-navy-850/60 backdrop-blur-sm sm:grid-cols-4 sm:divide-x">
          <Stat value={1200} suffix="+" label="Devices repaired" />
          <Stat value={850} suffix="+" label="Students trained" />
          <Stat value={64} suffix="+" label="Projects delivered" />
          <Stat value={99.8} suffix="%" decimals={1} label="Systems uptime" />
        </div>
      </div>
    </section>
  );
}
