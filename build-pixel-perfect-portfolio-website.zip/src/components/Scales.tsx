import { useMemo, useState } from "react";
import { useInView } from "../lib/hooks";
import { SectionHeading } from "./ui";

/* ------------------------------------------------------------------ */
/* Skill meters                                                        */
/* ------------------------------------------------------------------ */

const SKILLS = [
  { label: "IT Support & Hardware Repair", level: 96, note: "Diagnostics · board-level · upgrades" },
  { label: "Web & Mobile Development", level: 92, note: "React · TypeScript · PWA" },
  { label: "STEM Instruction & Robotics", level: 94, note: "Arduino · Lego · project-based" },
  { label: "Python & Automation", level: 88, note: "Flask · scripting · data tasks" },
  { label: "Graphic Design & Branding", level: 86, note: "Identity · print · social kits" },
  { label: "Networking & Cybersecurity", level: 82, note: "LAN/WLAN · hardening · backup" },
  { label: "AI Workflow Automation", level: 80, note: "Agents · prompt ops · integrations" },
];

function SkillPanel() {
  const { ref, inView } = useInView<HTMLDivElement>(0.2);
  return (
    <div ref={ref} className="reveal relative h-full" data-dir="left">
      <div className="h-full rounded-2xl border border-white/10 bg-navy-850/70 p-6 backdrop-blur-sm sm:p-8">
        <div className="flex items-baseline justify-between gap-4">
          <h3 className="font-display text-xl font-bold text-white">Skill scale</h3>
          <span className="font-script text-xl text-brand-400">measured, not guessed</span>
        </div>
        <ul className="mt-7 space-y-5">
          {SKILLS.map((s, i) => (
            <li key={s.label} className="group">
              <div className="flex items-end justify-between gap-3">
                <p className="text-[0.86rem] font-semibold text-white/85">{s.label}</p>
                <p className="font-display text-sm font-bold tabular-nums text-brand-400">{s.level}%</p>
              </div>
              <div className="mt-2 h-[7px] w-full overflow-hidden rounded-full bg-white/8">
                <div
                  className="h-full rounded-full bg-[linear-gradient(90deg,#1673d2,#3aa9ff_55%,#74c6ff)] shadow-[0_0_12px_rgba(58,169,255,.55)] transition-[width] duration-[1400ms] ease-out"
                  style={{ width: inView ? `${s.level}%` : "0%", transitionDelay: `${i * 110}ms` }}
                />
              </div>
              <p className="mt-1.5 text-[0.7rem] tracking-wide text-white/35">{s.note}</p>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Radial gauges                                                       */
/* ------------------------------------------------------------------ */

const GAUGES = [
  { value: 99.8, label: "System uptime", sub: "rolling 12 months", decimals: 1 },
  { value: 96, label: "Client retention", sub: "repeat customers", decimals: 0 },
  { value: 92, label: "First-visit fixes", sub: "repaired on site", decimals: 0 },
];

function Gauge({ value, label, sub, decimals }: (typeof GAUGES)[number]) {
  const { ref, inView } = useInView<HTMLDivElement>(0.4);
  const r = 42;
  const c = 2 * Math.PI * r;
  const offset = c * (1 - (inView ? value : 0) / 100);

  return (
    <div ref={ref} className="reveal group flex flex-col items-center text-center" data-dir="up">
      <div className="relative h-[124px] w-[124px]">
        <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90">
          <circle cx="50" cy="50" r={r} fill="none" stroke="rgba(255,255,255,.09)" strokeWidth="7" />
          <circle
            cx="50"
            cy="50"
            r={r}
            fill="none"
            stroke="url(#gaugeGrad)"
            strokeWidth="7"
            strokeLinecap="round"
            strokeDasharray={c}
            strokeDashoffset={offset}
            style={{ transition: "stroke-dashoffset 1.6s cubic-bezier(.22,1,.36,1)" }}
          />

        </svg>
        <div className="absolute inset-0 grid place-items-center">
          <p className="font-display text-xl font-extrabold tabular-nums text-white">
            {value.toFixed(decimals)}
            <span className="text-brand-400">%</span>
          </p>
        </div>
      </div>
      <p className="mt-3 text-[0.82rem] font-semibold text-white/85">{label}</p>
      <p className="text-[0.68rem] uppercase tracking-[.16em] text-white/35">{sub}</p>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Data scale explorer                                                 */
/* ------------------------------------------------------------------ */

const UNITS = [
  { name: "bit", bytes: 0.125 },
  { name: "byte", bytes: 1 },
  { name: "KB", bytes: 10 ** 3 },
  { name: "MB", bytes: 10 ** 6 },
  { name: "GB", bytes: 10 ** 9 },
  { name: "TB", bytes: 10 ** 12 },
  { name: "PB", bytes: 10 ** 15 },
];

const BINARY_UNITS = [
  { name: "bit", bytes: 0.125 },
  { name: "B", bytes: 1 },
  { name: "KiB", bytes: 1024 },
  { name: "MiB", bytes: 1024 ** 2 },
  { name: "GiB", bytes: 1024 ** 3 },
  { name: "TiB", bytes: 1024 ** 4 },
  { name: "PiB", bytes: 1024 ** 5 },
];

const EQUIV = [
  { icon: "💬", label: "text messages", bytes: 160 },
  { icon: "📷", label: "smartphone photos", bytes: 3 * 10 ** 6 },
  { icon: "🎵", label: "MP3 songs", bytes: 5 * 10 ** 6 },
  { icon: "🎬", label: "HD movies", bytes: 4 * 10 ** 9 },
  { icon: "🧬", label: "human genomes", bytes: 1.5 * 10 ** 9 },
  { icon: "📚", label: "e-books", bytes: 1.2 * 10 ** 6 },
];

const compact = new Intl.NumberFormat("en-US", { notation: "compact", maximumFractionDigits: 2 });
const plain = new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 });

function fmt(n: number) {
  if (!isFinite(n)) return "—";
  if (n === 0) return "0";
  if (Math.abs(n) < 0.001) return n.toExponential(1);
  if (Math.abs(n) >= 1e7) return compact.format(n);
  return plain.format(n);
}

function DataScale() {
  const [amount, setAmount] = useState("1");
  const [unitIdx, setUnitIdx] = useState(4);
  const [binary, setBinary] = useState(false);

  const units = binary ? BINARY_UNITS : UNITS;
  const bytes = useMemo(() => {
    const n = parseFloat(amount);
    if (isNaN(n)) return 0;
    return n * units[unitIdx].bytes;
  }, [amount, unitIdx, units]);

  const logPos = useMemo(() => {
    if (bytes <= 0) return 0;
    const min = Math.log10(0.125);
    const max = Math.log10(1024 ** 5);
    return Math.min(100, Math.max(0, ((Math.log10(bytes) - min) / (max - min)) * 100));
  }, [bytes]);

  return (
    <div className="reveal relative overflow-hidden rounded-2xl border border-white/10 bg-navy-850/70 backdrop-blur-sm" data-dir="up">
      <div className="pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full bg-brand-500/15 blur-3xl" />
      <div className="relative grid gap-8 p-6 sm:p-8 lg:grid-cols-[0.9fr_1.1fr] lg:gap-10">
        {/* controls */}
        <div>
          <div className="flex items-baseline justify-between gap-3">
            <h3 className="font-display text-xl font-bold text-white">Data scale explorer</h3>
            <span className="font-script text-xl text-brand-400">how big is it?</span>
          </div>
          <p className="mt-2 text-sm leading-relaxed text-white/50">
            A live logarithmic converter — from a single bit up to petabytes — so clients can see exactly what a backup,
            a film library or a school server actually means.
          </p>

          <div className="mt-6 flex flex-wrap items-end gap-3">
            <label className="flex-1">
              <span className="mb-1.5 block text-[0.68rem] font-semibold uppercase tracking-[.18em] text-white/40">
                Amount
              </span>
              <input
                type="number"
                min="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full rounded-xl border border-white/12 bg-navy-900/80 px-4 py-3 font-display text-lg font-bold tabular-nums text-white outline-none transition-colors focus:border-brand-400"
              />
            </label>
            <label className="flex-1">
              <span className="mb-1.5 block text-[0.68rem] font-semibold uppercase tracking-[.18em] text-white/40">
                Unit
              </span>
              <select
                value={unitIdx}
                onChange={(e) => setUnitIdx(Number(e.target.value))}
                className="w-full appearance-none rounded-xl border border-white/12 bg-navy-900/80 px-4 py-3 font-display text-lg font-bold text-white outline-none transition-colors focus:border-brand-400"
              >
                {units.map((u, i) => (
                  <option key={u.name} value={i} className="bg-navy-900">
                    {u.name}
                  </option>
                ))}
              </select>
            </label>
          </div>

          <div className="mt-4 inline-flex rounded-full border border-white/12 p-1">
            {[
              { key: false, label: "Decimal (KB = 1000 B)" },
              { key: true, label: "Binary (KiB = 1024 B)" },
            ].map((opt) => (
              <button
                key={String(opt.key)}
                type="button"
                onClick={() => setBinary(opt.key)}
                className={`rounded-full px-3.5 py-1.5 text-[0.72rem] font-semibold transition-colors duration-300 ${
                  binary === opt.key ? "bg-brand-500 text-white" : "text-white/55 hover:text-white"
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          {/* log scale */}
          <div className="mt-7">
            <div className="relative h-2 rounded-full bg-[linear-gradient(90deg,#1e8ff5,#2fe3a6_45%,#ffd21f_70%,#ff3d8b)]">
              <div
                className="absolute -top-1.5 h-5 w-5 -translate-x-1/2 rounded-full border-2 border-navy-900 bg-white shadow-[0_0_0_4px_rgba(30,143,245,.28)] transition-[left] duration-500 ease-out"
                style={{ left: `${logPos}%` }}
              />
            </div>
            <div className="mt-2.5 flex justify-between text-[0.62rem] font-semibold uppercase tracking-[.12em] text-white/40">
              {(binary ? BINARY_UNITS : UNITS).map((u) => (
                <span key={u.name}>{u.name}</span>
              ))}
            </div>
            <p className="mt-4 font-display text-sm text-white/70">
              = <span className="font-bold text-white">{fmt(bytes)}</span> bytes
              <span className="ml-2 text-white/40">
                (2^{bytes > 0 ? Math.max(0, Math.round(Math.log2(bytes))) : 0} power of two)
              </span>
            </p>
          </div>
        </div>

        {/* conversions */}
        <div>
          <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4 lg:grid-cols-3">
            {(binary ? BINARY_UNITS : UNITS).map((u, i) => {
              const val = bytes / u.bytes;
              const active = i === unitIdx;
              return (
                <div
                  key={u.name}
                  className={`rounded-xl border px-3 py-3 transition-all duration-300 ${
                    active
                      ? "border-brand-400/60 bg-brand-500/12 shadow-[0_0_24px_-8px_rgba(30,143,245,.7)]"
                      : "border-white/8 bg-navy-900/50 hover:border-white/20"
                  }`}
                >
                  <p className="text-[0.66rem] font-semibold uppercase tracking-[.16em] text-white/40">{u.name}</p>
                  <p className="mt-1 font-display text-base font-bold tabular-nums text-white">{fmt(val)}</p>
                </div>
              );
            })}
          </div>

          <p className="mt-7 text-[0.68rem] font-semibold uppercase tracking-[.18em] text-white/40">
            Roughly the same as
          </p>
          <ul className="mt-3 grid gap-2.5 sm:grid-cols-2">
            {EQUIV.map((e) => {
              const count = bytes / e.bytes;
              return (
                <li
                  key={e.label}
                  className="group flex items-center gap-3 rounded-xl border border-white/8 bg-navy-900/50 px-3.5 py-3 transition-colors duration-300 hover:border-brand-400/40 hover:bg-brand-500/8"
                >
                  <span className="text-xl transition-transform duration-300 group-hover:scale-125">{e.icon}</span>
                  <span className="min-w-0">
                    <span className="block font-display text-sm font-bold tabular-nums text-white">
                      {count >= 100 ? compact.format(count) : plain.format(Math.round(count * 10) / 10)}
                    </span>
                    <span className="block truncate text-[0.72rem] text-white/45">{e.label}</span>
                  </span>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Stack marquee                                                       */
/* ------------------------------------------------------------------ */

const STACK = [
  "React", "TypeScript", "Python", "Flask", "Node.js", "Tailwind CSS", "MySQL",
  "WordPress", "Arduino", "Raspberry Pi", "Figma", "Git & GitHub", "Linux",
  "MikroTik", "cPanel", "Google Workspace",
];

function StackMarquee() {
  const row = [...STACK, ...STACK];
  return (
    <div className="relative mt-12 overflow-hidden [mask-image:linear-gradient(90deg,transparent,#000_12%,#000_88%,transparent)]">
      <div className="marquee-track flex w-max gap-3">
        {row.map((t, i) => (
          <span
            key={`${t}-${i}`}
            className="whitespace-nowrap rounded-full border border-white/10 bg-navy-850/70 px-5 py-2.5 text-[0.82rem] font-semibold text-white/70 transition-colors duration-300 hover:border-brand-400/50 hover:text-white"
          >
            {t}
          </span>
        ))}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

export default function Scales() {
  return (
    <section id="scales" className="relative overflow-hidden py-20 sm:py-28">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-brand-400/30 to-transparent" />
      <div className="pointer-events-none absolute -right-40 top-40 h-[28rem] w-[28rem] rounded-full bg-brand-600/12 blur-[130px]" />
      <svg className="absolute h-0 w-0" aria-hidden="true">
        <defs>
          <linearGradient id="gaugeGrad" x1="0" y1="0" x2="1" y2="1">
            <stop stopColor="#1673d2" />
            <stop offset="1" stopColor="#74c6ff" />
          </linearGradient>
        </defs>
      </svg>

      <div className="relative mx-auto max-w-[1200px] px-5 sm:px-8">
        <SectionHeading
          align="center"
          eyebrow="Computing scales"
          script="Scaling skills, systems & storage"
          title="Computing"
          accent="scales"
          copy="Every project gets measured — capability, reliability and capacity. Here's the honest scale of what I work with, plus a live data-scale explorer you can play with."
        />

        <div className="mt-14 grid gap-6 lg:grid-cols-2">
          <SkillPanel />

          <div className="grid gap-6">
            <div className="reveal rounded-2xl border border-white/10 bg-navy-850/70 p-6 backdrop-blur-sm sm:p-8" data-dir="right">
              <div className="flex items-baseline justify-between gap-4">
                <h3 className="font-display text-xl font-bold text-white">Performance gauges</h3>
                <span className="font-script text-xl text-brand-400">tracked monthly</span>
              </div>
              <div className="mt-8 grid grid-cols-3 gap-4">
                {GAUGES.map((g) => (
                  <Gauge key={g.label} {...g} />
                ))}
              </div>
            </div>

            <div className="reveal grid gap-3 sm:grid-cols-3" data-dir="right">
              {[
                { k: "4 h", v: "Average on-site response in Accra" },
                { k: "24/7", v: "Remote support & monitoring" },
                { k: "3 GB", v: "Mean backup footprint per client" },
              ].map((c) => (
                <div
                  key={c.k}
                  className="group rounded-2xl border border-white/10 bg-[linear-gradient(150deg,rgba(23,57,95,.55),rgba(8,22,42,.7))] p-5 transition-all duration-500 hover:-translate-y-1 hover:border-brand-400/40"
                >
                  <p className="font-display text-2xl font-extrabold text-white transition-colors group-hover:text-brand-300">
                    {c.k}
                  </p>
                  <p className="mt-1.5 text-[0.78rem] leading-snug text-white/50">{c.v}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-6">
          <DataScale />
        </div>

        <StackMarquee />
      </div>
    </section>
  );
}
