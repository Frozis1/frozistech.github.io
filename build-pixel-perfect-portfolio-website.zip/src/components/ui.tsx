import type { ReactNode } from "react";
import { useCountUp, useInView } from "../lib/hooks";

export function Eyebrow({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center gap-2.5 rounded-full border border-brand-400/30 bg-brand-500/10 px-4 py-1.5 text-[0.68rem] font-semibold uppercase tracking-[.24em] text-brand-300">
      <span className="relative flex h-1.5 w-1.5">
        <span className="ping-slow absolute inline-flex h-full w-full rounded-full bg-brand-400" />
        <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-brand-400" />
      </span>
      {children}
    </span>
  );
}

export function SectionHeading({
  eyebrow,
  script,
  title,
  accent,
  copy,
  align = "left",
}: {
  eyebrow: string;
  script?: string;
  title: string;
  accent?: string;
  copy?: string;
  align?: "left" | "center";
}) {
  return (
    <div className={align === "center" ? "mx-auto max-w-2xl text-center" : "max-w-2xl"}>
      <div className={align === "center" ? "flex justify-center" : ""}>
        <div className="reveal" data-dir="up">
          <Eyebrow>{eyebrow}</Eyebrow>
        </div>
      </div>
      {script && (
        <p className="reveal mt-5 font-script text-3xl leading-none text-brand-400" data-dir="up">
          {script}
        </p>
      )}
      <h2
        className="reveal mt-2 font-display text-3xl font-extrabold leading-[1.12] text-white sm:text-4xl lg:text-[2.75rem]"
        data-dir="up"
        style={{ transitionDelay: "80ms" }}
      >
        {title} {accent && <span className="text-gradient-brand">{accent}</span>}
      </h2>
      {copy && (
        <p
          className="reveal mt-4 text-[0.98rem] leading-relaxed text-white/60"
          data-dir="up"
          style={{ transitionDelay: "160ms" }}
        >
          {copy}
        </p>
      )}
    </div>
  );
}

export function Stat({
  value,
  suffix,
  label,
  decimals = 0,
}: {
  value: number;
  suffix?: string;
  label: string;
  decimals?: number;
}) {
  const { ref, inView } = useInView<HTMLDivElement>(0.4);
  const n = useCountUp(value, inView, 1700);

  return (
    <div ref={ref} className="reveal group relative px-2 py-4 text-center" data-dir="up">
      <div className="absolute inset-x-6 top-0 h-px bg-gradient-to-r from-transparent via-brand-400/50 to-transparent" />
      <p className="font-display text-4xl font-extrabold tracking-tight text-white sm:text-5xl">
        <span className="tabular-nums">
          {n.toLocaleString("en-US", { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}
        </span>
        <span className="text-brand-400">{suffix}</span>
      </p>
      <p className="mt-2 text-[0.72rem] font-semibold uppercase tracking-[.18em] text-white/45">{label}</p>
    </div>
  );
}
