import { useEffect, useState } from "react";
import { ArrowIcon, CloseIcon, LogoMark, MenuIcon } from "./Icons";
import { useScrollY } from "../lib/hooks";

const LINKS = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Services", href: "#services" },
  { label: "Scales", href: "#scales" },
  { label: "Work", href: "#work" },
  { label: "Contact", href: "#contact" },
];

export default function Nav() {
  const scrollY = useScrollY();
  const [open, setOpen] = useState(false);
  const solid = scrollY > 300;

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <>
      <nav
        className={`fixed inset-x-0 top-0 z-50 border-b transition-all duration-500 ${
          solid
            ? "border-white/10 bg-navy-900/85 py-2.5 shadow-[0_10px_40px_-18px_rgba(0,0,0,.9)] backdrop-blur-xl"
            : "border-transparent bg-transparent py-4 lg:pointer-events-none lg:-translate-y-full lg:opacity-0"
        }`}
      >
        <div className="mx-auto flex max-w-[1400px] items-center justify-between px-5 sm:px-8">
          <a
            href="#home"
            className={`group flex items-center gap-3 transition-all duration-500 ${
              solid ? "opacity-100" : "pointer-events-none opacity-0"
            }`}
          >
            <LogoMark className="w-8 text-white transition-transform duration-500 group-hover:scale-110 sm:w-9" />
            <span className="hidden flex-col leading-none sm:flex">
              <span className="font-display text-[0.95rem] font-extrabold tracking-wide text-white">
                RICHARD <span className="text-brand-500">ADJEI</span> MENSAH
              </span>
              <span className="mt-1 text-[0.62rem] font-medium tracking-[.22em] text-brand-300/80">
                TECH · STEM · DIGITAL
              </span>
            </span>
          </a>

          <ul className="hidden items-center gap-1 lg:flex">
            {LINKS.map((l) => (
              <li key={l.href}>
                <a
                  href={l.href}
                  className="group relative block px-4 py-2 text-[0.86rem] font-medium text-white/75 transition-colors duration-300 hover:text-white"
                >
                  {l.label}
                  <span className="absolute inset-x-4 bottom-1 h-px origin-left scale-x-0 bg-brand-400 transition-transform duration-300 group-hover:scale-x-100" />
                </a>
              </li>
            ))}
          </ul>

          <div className="flex items-center gap-3">
            <a
              href="#contact"
              className="group hidden items-center gap-2 rounded-full bg-brand-500 px-5 py-2.5 text-[0.84rem] font-semibold text-white transition-all duration-300 hover:bg-brand-400 hover:shadow-glow sm:inline-flex"
            >
              Hire me
              <ArrowIcon className="w-4 transition-transform duration-300 group-hover:translate-x-1" />
            </a>
            <button
              type="button"
              onClick={() => setOpen(true)}
              aria-label="Open menu"
              className="grid h-10 w-10 place-items-center rounded-lg border border-white/15 text-white transition-colors hover:border-brand-400 hover:text-brand-400 lg:hidden"
            >
              <MenuIcon className="w-5" />
            </button>
          </div>
        </div>
      </nav>

      {/* mobile drawer */}
      <div
        className={`fixed inset-0 z-[60] lg:hidden ${open ? "pointer-events-auto" : "pointer-events-none"}`}
        aria-hidden={!open}
      >
        <div
          onClick={() => setOpen(false)}
          className={`absolute inset-0 bg-navy-950/80 backdrop-blur-sm transition-opacity duration-300 ${
            open ? "opacity-100" : "opacity-0"
          }`}
        />
        <div
          className={`absolute right-0 top-0 h-full w-[78%] max-w-xs border-l border-white/10 bg-navy-900 p-6 transition-transform duration-500 ${
            open ? "translate-x-0" : "translate-x-full"
          }`}
        >
          <div className="flex items-center justify-between">
            <LogoMark className="w-8 text-white" />
            <button
              type="button"
              onClick={() => setOpen(false)}
              aria-label="Close menu"
              className="grid h-10 w-10 place-items-center rounded-lg border border-white/15 text-white"
            >
              <CloseIcon className="w-5" />
            </button>
          </div>
          <ul className="mt-8 space-y-1">
            {LINKS.map((l) => (
              <li key={l.href}>
                <a
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="block border-b border-white/5 py-3 font-display text-lg font-semibold text-white/85 transition-colors hover:text-brand-400"
                >
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
          <a
            href="#contact"
            onClick={() => setOpen(false)}
            className="mt-8 flex items-center justify-center gap-2 rounded-full bg-brand-500 px-5 py-3 font-semibold text-white"
          >
            Hire me <ArrowIcon className="w-4" />
          </a>
          <p className="mt-8 text-sm text-white/50">Greater Accra, Ghana</p>
          <a href="tel:+233546093300" className="text-sm text-brand-300">
            +233 546 093 300
          </a>
        </div>
      </div>
    </>
  );
}
