/**
 * ------------------------------------------------------------------
 *  PORTRAIT
 * ------------------------------------------------------------------
 *  The About section reads the portrait from `public/images/portrait.jpg`.
 *
 *  To show YOUR exact photo:
 *    1. Save the file as: public/images/portrait.jpg
 *    2. Change HAS_PORTRAIT below to `true`.
 *
 *  Nothing else needs editing — the <img> already points at that path.
 *  While HAS_PORTRAIT is false, the panel renders the branded identity
 *  card instead, so no placeholder face is ever shown.
 */
export const PORTRAIT_SRC = "/images/portrait.jpg";
export const HAS_PORTRAIT = false;

export const PROFILE = {
  name: "Richard Adjei Mensah",
  roles: "Tech Educator · Developer · IT Specialist",
  location: "Greater Accra, Ghana",
  phone: "+233 546 093 300",
  phoneHref: "tel:+233546093300",
  email: "richardadjeimenz24@gmail.com",
};
